import mongoose from 'mongoose';
import crypto from 'crypto';

// Ensure that you define an encryption key in your environment variables
const ENCRYPTION_KEY = Buffer.from(process.env.ENCRYPTION_KEY, 'utf-8'); // Use Buffer from your 32-byte key
const ALGORITHM = 'aes-256-cbc'; // AES encryption algorithm

const vaultSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  vaultFolder: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'VaultFolder',
    required: false
  },
  name: {
    type: String,
    required: true
  },
  URL: {
    type: String
  },
  username: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  notes: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Encrypt sensitive fields before saving to the database
vaultSchema.pre('save', function(next) {
  try {
    if (this.isModified('password') || this.isNew) {
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
      let encrypted = cipher.update(this.password, 'utf8', 'hex');
      encrypted += cipher.final('hex');
      this.password = `${iv.toString('hex')}:${encrypted}`;
      console.log('Encrypted password:', this.password);
    }

    if (this.isModified('URL') || this.isNew) {
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
      let encrypted = cipher.update(this.URL, 'utf8', 'hex');
      encrypted += cipher.final('hex');
      this.URL = `${iv.toString('hex')}:${encrypted}`;
      console.log('Encrypted URL:', this.URL);
    }

    if (this.isModified('notes') || this.isNew) {
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
      let encrypted = cipher.update(this.notes, 'utf8', 'hex');
      encrypted += cipher.final('hex');
      this.notes = `${iv.toString('hex')}:${encrypted}`;
      console.log('Encrypted notes:', this.notes);
    }

    next();
  } catch (error) {
    console.error('Error during encryption:', error);
    next(error);
  }
});



// Decrypt fields
vaultSchema.methods.decryptFields = function() {
  try {
    // Decrypt URL
    let decryptedURL = '';
    if (this.URL) {
      const [urlIv, urlEncrypted] = this.URL.split(':');
      const urlDecipher = crypto.createDecipheriv(ALGORITHM, ENCRYPTION_KEY, Buffer.from(urlIv, 'hex'));
      decryptedURL = urlDecipher.update(urlEncrypted, 'hex', 'utf8');
      decryptedURL += urlDecipher.final('utf8');
    }

    // Decrypt notes
    let decryptedNotes = '';
    if (this.notes) {
      const [notesIv, notesEncrypted] = this.notes.split(':');
      const notesDecipher = crypto.createDecipheriv(ALGORITHM, ENCRYPTION_KEY, Buffer.from(notesIv, 'hex'));
      decryptedNotes = notesDecipher.update(notesEncrypted, 'hex', 'utf8');
      decryptedNotes += notesDecipher.final('utf8');
    }

    // Decrypt password
    let decryptedPassword = '';
    if (this.password) {
      const [passwordIv, passwordEncrypted] = this.password.split(':');
      const passwordDecipher = crypto.createDecipheriv(ALGORITHM, ENCRYPTION_KEY, Buffer.from(passwordIv, 'hex'));
      decryptedPassword = passwordDecipher.update(passwordEncrypted, 'hex', 'utf8');
      decryptedPassword += passwordDecipher.final('utf8');
    }

    return {
      _id: this._id,
      name: this.name,
      URL: decryptedURL,
      username: this.username,
      password: decryptedPassword,
      notes: decryptedNotes
    };
  } catch (error) {
    console.error('Error during decryption:', error);
    return {}; // Return an empty object or handle the error as needed
  }
};

const Vault = mongoose.models.Vault || mongoose.model('Vault', vaultSchema);
export default Vault;
